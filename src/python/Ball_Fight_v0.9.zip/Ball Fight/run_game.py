#!/usr/bin/env python
import os, sys

try:
    __file__
except NameError:
    print "Warning, __file__ not setted"
else:
    libdir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'gamelib'))
    sys.path.insert(0, libdir)

import BF
BF.start_game()

