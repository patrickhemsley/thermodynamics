Ball Fight v0.9
===============
https://sourceforge.net/projects/ballfight/
zahamiedivad@hotmail.it


DEPENDENCIES:

	Python:	http://www.python.org/
	PyGame:	http://www.pygame.org/


RUNNING THE GAME:

	On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

	Othewise open a terminal / console and "cd" to the game directory and run:
		python run_game.py


DESCRIPTION:

	In this game you have to destroy as much balls as possible colliding
	with them using yours, or using special powers. Each ball raises its resistance
	and its attack when it speeds up. So the faster you go, the more you are protected
	against enemies attacks and the more you inflict damage colliding with other balls!
	This is valid for your enemies too!
	See the ingame help for more details.


INFO ABOUT COPYRIGHT:

	Copyright (C) 2010  Davide Zagami

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.

