# Ball Fight Copyright (C) 2010 Davide Zagami
# See BF.py for info about Copyright
import sys, pygame
from pygame.locals import *
from zModule import *
from BFobjs import *
from BFparticles import *

class BFGame:

	def __init__(self,bf):
		self.bf=bf
		self.background = load_image(os.path.join(picsdir,"background.png"))[0]
		self.background2 = load_image(os.path.join(picsdir,"background2.png"))[0]
		self.game_background = load_image(os.path.join(picsdir,"game_background.png"))[0]
		self.game_help = load_image(os.path.join(picsdir,"help.png"),"alpha")[0]
		self.game_music = load_sound(os.path.join(soundsdir,"NemesisTheory - Overdriven.ogg"))
		self.volume = 0.6
		self.game_music.set_volume(self.volume)
		self.explosion_sound = load_sound(os.path.join(soundsdir,"explosion.ogg"))
		self.powerup_sound = load_sound(os.path.join(soundsdir,"powerup.ogg"))
		self.explosion_sound.set_volume(1.0)
		self.powerup_sound.set_volume(1.0)
		self.screen = pygame.display.get_surface()
		self.clock = pygame.time.Clock()
		self.fps = 40
		self.time = -1.0
		self.game = False
		self.mainmenu = True
		self.zfullscreen = zCheckbutton("Fullscreen", (500,200), self.fullscreenOn, self.fullscreenOff, 4, None, BLACK, BLACK, RED)
		self.zaudio = zCheckbutton("Audio", (500,250), self.audioOn, self.audioOff, 4, None, BLACK, BLACK, RED, True)
		self.Menu2 = zMenu("", (400,130), 1, move=os.path.join(soundsdir,"menu_move.ogg"), select=os.path.join(soundsdir,"menu_select.ogg"))
		self.Menu2.submenu("Resume", self.Resume)
		self.Menu2.submenu("New Game", self.NewGame)
		self.Menu2.submenu("Back", self.toMainMenu)
		self.Menu2.set_normal_color(BLACK)
		self.Menu2.set_highlight_color(GRAY)
		self.Menu2.set_dim(30)
		self.Menu2.sounds_player(self.zaudio.select)
		self.Menu2.sounds_stopper(self.zaudio.unselect)
		self.OptionsTitle = zAdvText("Options", (0,0), 80, None, BLACK)
		self.OptionsTitle.center_at(400,80)
		self.HelpTitle = zAdvText("Help", (0,0), 80, None, BLACK)
		self.HelpTitle.center_at(400,80)
		self.HSTitle = zAdvText("Highscores", (0,0), 80, None, BLACK)
		self.HSTitle.center_at(400,80)
		self.pausetxt = zAdvText("PAUSED", (0,0), 60, None, BLACK)
		self.pausetxt.center_at(450,300)
		self.gameovertxt = zAdvText("GAME OVER", (0,0), 100, None, BLACK)
		self.gameovertxt.center_at(400,300)
		self.esctoreturn = zAdvText("Press ESC to return", (0,0), 50, None, BLACK)
		self.esctoreturn.center_at(400,570)
		self.nemesistheory_credit = zAdvText("Music by NemesisTheory", (0,0), 25, None, WHITE)
		self.nemesistheory_credit.center_at(680,580)
		self.player = BFPlayer(self)
		self.enemies = pygame.sprite.RenderPlain(())
		self.pwups = pygame.sprite.RenderPlain(())
		self.enemies_used = [Tiny, Tinyfast, Small, Smallfast, Medium, Iper, Big, WOOT, Planet, SuperPlanet]
		self.pwups_used = [Kill1, KillAll, Health, SuperHealth, Godmode, Speed, Tank, Blackhole]
		self.particleManager = ParticleManager()
		self.highscores = []
		self.load_highscores()

	def Resume(self):
		self.mainmenu = True
		self.run()

	def NewGame(self):
		self.reset()
		self.run()

	def toMainMenu(self):
		self.mainmenu = True

	def run(self):
		self.game = True
		self.time = -1.0
		seconds = 0.0
		self.game_music.play(-1)
		self.bf.MainMenu.stop_music()
		while self.game:
			self.clock.tick(self.fps)
			self.time += 1.0
			if self.time/self.fps == 1.0:
				seconds += 1.0
				self.time = 0.0
				for e in self.enemies_used:
					if rand(0,e.rate) == int(e.rate/2):
						self.enemies.add(e(self))
						break
				for p in self.pwups_used:
					if rand(0,p.rate) == int(p.rate/2):
						self.pwups.add(p(self))



			for event in pygame.event.get():
				if event.type == QUIT:
					self.Quit()
				elif event.type == KEYDOWN:
					if event.key == K_ESCAPE:
						self.Menu2.select.play()
						self.game_music.fadeout(500)
						self.bf.MainMenu.play_music()
						return
					elif event.key == K_p:
						self.Pause()
					elif event.key == K_m:
						if self.zaudio.state:
							self.zaudio.unselect()
						else:
							self.zaudio.select()

			self.pwups.update()
			self.player.update()
			if self.player.life <= 0: self.GameOver()
			for enemy in self.enemies:
				enemy.update()
				if enemy.life <=0: enemy.destroy()
			self.particleManager.update()
			self.screen.blit(self.game_background,(0,0))
			self.pwups.draw(self.screen)
			for enemy in self.enemies:
				enemy.draw(self.screen)
			self.player.draw(self.screen)
			self.particleManager.render()
			pygame.display.flip()

	def explosion(self,x,y,color,rad):
		numParticles = random()*5*rad+5*rad
		for i in range(int(numParticles)):
			xspeed = random()*5
			yspeed = random()*5

			if int(xspeed) is 0:
				yspeed+=1
			if random()<0.5:
				xspeed *= -1
			if random()<0.5:
				yspeed *= -1 

			particle = Particle(x,y,xspeed,yspeed,color,random()*4*rad+rad/2)
			self.particleManager.queueAddParticle(particle)
		self.explosion_sound.play()

	def Pause(self):
		self.pausetxt.draw(self.screen)
		pygame.display.flip()
		while True:
			self.clock.tick(10)
			for e in pygame.event.get():
				if e.type == QUIT:
					self.Quit()
				elif e.type == KEYDOWN:
					if e.key == K_p:
						return
					elif e.key == K_ESCAPE:
						self.game = False
						return
					elif e.key == K_m:
						if self.zaudio.state:
							self.zaudio.unselect()
						else:
							self.zaudio.select()

	def GameOver(self):
		self.check_highscores()
		self.player.destroy()
		self.screen.blit(self.game_background,(0,0))
		self.enemies.draw(self.screen)
		self.pwups.draw(self.screen)
		self.player.showHP(self.screen)
		background = self.screen.copy()
		i=0
		while i<120:
			self.clock.tick(40)
			self.particleManager.update()
			self.screen.blit(background, (0,0))
			self.particleManager.render()
			pygame.display.flip()
			i+=1
		self.gameovertxt.draw(self.screen)
		pygame.display.flip()
		self.reset()
		self.game_music.fadeout(2000)
		pygame.time.delay(2000)
		self.bf.MainMenu.play_music()
		return

	def reset(self):
		del self.player
		self.player = BFPlayer(self)
		self.enemies.empty()
		self.pwups.empty()
		self.particleManager.delAll()
		self.game = False
		self.mainmenu = True


	def fullscreenOn(self):
		self.screen = pygame.display.set_mode((800,600),FULLSCREEN)

	def fullscreenOff(self):
		self.screen = pygame.display.set_mode((800,600))

	def audioOn(self):
		self.bf.MainMenu.music.set_volume(self.bf.MainMenu.volume)
		self.bf.MainMenu.move.set_volume(1.0)
		self.bf.MainMenu.select.set_volume(1.0)
		self.bf.MainMenu.audio = True
		self.Menu2.move.set_volume(1.0)
		self.Menu2.select.set_volume(1.0)
		self.Menu2.audio = True
		self.game_music.set_volume(self.volume)
		self.explosion_sound.set_volume(1.0)
		self.powerup_sound.set_volume(1.0)

	def audioOff(self):
		self.bf.MainMenu.music.set_volume(0.0)
		self.bf.MainMenu.move.set_volume(0.0)
		self.bf.MainMenu.select.set_volume(0.0)
		self.bf.MainMenu.audio = False
		self.Menu2.move.set_volume(0.0)
		self.Menu2.select.set_volume(0.0)
		self.Menu2.audio = False
		self.game_music.set_volume(0.0)
		self.explosion_sound.set_volume(0.0)
		self.powerup_sound.set_volume(0.0)


	def load_highscores(self):
		f = open(highscorespath,'r')
		self.highscores = list_stoi(f.read().split("\n")[:-1])
		f.close()

	def save_highscores(self):
		f = open(highscorespath,'w')
		f.write('\n'.join(list_itos(self.highscores)))
		f.close()

	def check_highscores(self):
		if self.player.score > self.highscores[len(self.highscores)-1]:
			del self.highscores[len(self.highscores)-1]
			self.highscores.append(int(self.player.score))
			self.highscores.sort()
			self.highscores.reverse()
			self.save_highscores()

	def Play(self):
		if not self.game:
			self.NewGame()

		else:
			background = self.screen.copy()
			background.set_alpha(180)
			self.mainmenu = False
			while not self.mainmenu:
				self.clock.tick(20)

				events = pygame.event.get()
				for event in events:
					if event.type == QUIT:
						self.Quit()
					if event.type == KEYDOWN:
						if event.key == K_ESCAPE:
							self.Menu2.select.play()
							self.mainmenu = True

				self.Menu2.update(events)
				self.screen.fill(0xffffff)
				self.screen.blit(background,(0,0))
				self.screen.blit(self.background2,(300,110))
				self.Menu2.draw(self.screen)
				pygame.display.flip()

	def HS(self):
		while True:
			self.clock.tick(20)

			events = pygame.event.get()
			for e in events:
				if e.type == QUIT:
					self.Quit()
				elif e.type == KEYDOWN:
					if e.key == K_ESCAPE:
						self.Menu2.select.play()
						return
					elif e.key == K_m:
						if self.zaudio.state:
							self.zaudio.unselect()
						else:
							self.zaudio.select()

			self.screen.blit(self.background,(0,0))
			self.HSTitle.draw(self.screen)
			self.esctoreturn.draw(self.screen)
			y=110
			i=1
			for h in self.highscores:
				zTextDraw(self.screen, ("%02d) "%i)+str(h), 25, (350,y+i*20), None, BLACK)
				i+=1
			pygame.display.flip()

	def Options(self):
		while True:
			self.clock.tick(20)

			events = pygame.event.get()
			for e in events:
				if e.type == QUIT:
					self.Quit()
				elif e.type == KEYDOWN:
					if e.key == K_ESCAPE:
						self.Menu2.select.play()
						return
					elif e.key == K_m:
						if self.zaudio.state:
							self.zaudio.unselect()
						else:
							self.zaudio.select()

			self.zfullscreen.update(events)
			self.zaudio.update(events)
			self.screen.blit(self.background,(0,0))
			self.OptionsTitle.draw(self.screen)
			self.esctoreturn.draw(self.screen)
			self.zfullscreen.draw(self.screen)
			self.zaudio.draw(self.screen)
			pygame.display.flip()

	def Help(self):
		while True:
			self.clock.tick(20)

			events = pygame.event.get()
			for e in events:
				if e.type == QUIT:
					self.Quit()
				elif e.type == KEYDOWN:
					if e.key == K_ESCAPE:
						self.Menu2.select.play()
						return
					elif e.key == K_m:
						if self.zaudio.state:
							self.zaudio.unselect()
						else:
							self.zaudio.select()

			self.screen.blit(self.background,(0,0))
			self.HelpTitle.draw(self.screen)
			self.screen.blit(self.game_help,(10,120))
			self.esctoreturn.draw(self.screen)
			self.nemesistheory_credit.draw(self.screen)
			pygame.display.flip()

	def Quit(self):
		self.Menu2.select.play()
		pygame.quit()
		sys.exit(0)


def list_stoi(l):
	i=0
	a=l
	while i<len(a):
		a[i] = int(a[i])
		i+=1
	return a

def list_itos(l):
	i=0
	a=l
	while i<len(a):
		a[i] = str(a[i])
		i+=1
	return a

