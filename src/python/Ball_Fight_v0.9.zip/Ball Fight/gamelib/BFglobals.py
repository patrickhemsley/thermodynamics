# Ball Fight Copyright (C) 2010 Davide Zagami
# See BF.py for info about Copyright
import os
picsdir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'pics'))
soundsdir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'sounds'))
highscorespath = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'highscores.dat'))
icon = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'icon.png'))
XMINBOUND = 10
YMINBOUND = 40
XMAXBOUND  = 790
YMAXBOUND  = 590

