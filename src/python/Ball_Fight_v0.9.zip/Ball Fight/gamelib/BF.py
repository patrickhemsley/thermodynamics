#!/usr/bin/python
# Ball Fight (see README.txt for a brief description)
# Copyright (C) 2010 Davide Zagami

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
from zModule import *
from BFmain import *

def start_game():
	if not pygame.font: print 'Warning, fonts disabled'
	if not pygame.mixer: print 'Warning, sound disabled'
	os.environ['SDL_VIDEO_CENTERED'] = '1'
	BF = zEngine(800, 600, "Ball Fight", icon, None, 80, None, BLACK, background=os.path.join(picsdir,"background.png"),
					music=os.path.join(soundsdir,"menu.ogg"), move=os.path.join(soundsdir,"menu_move.ogg"),
					select=os.path.join(soundsdir,"menu_select.ogg"), volume=0.6)
	game = BFGame(BF)
	BF.MainMenu.submenu("Play", game.Play)
	BF.MainMenu.submenu("Highscores", game.HS)
	BF.MainMenu.submenu("Options", game.Options)
	BF.MainMenu.submenu("Help", game.Help)
	BF.MainMenu.submenu("Exit", game.Quit)
	BF.MainMenu.set_normal_color(BLACK)
	BF.MainMenu.set_highlight_color(GRAY)
	BF.MainMenu.set_dim(30)
	BF.MainMenu.sounds_player(game.zaudio.select)
	BF.MainMenu.sounds_stopper(game.zaudio.unselect)
	BF.mainloop()


if __name__ == '__main__':
  start_game()

