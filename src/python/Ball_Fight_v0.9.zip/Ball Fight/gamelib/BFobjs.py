# Ball Fight Copyright (C) 2010 Davide Zagami
# See BF.py for info about Copyright
import pygame, math
from pygame.locals import *
from random import randint as rand
from random import random
from BFglobals import *
from zModule import zTextDraw, load_image, load_sound

def calcCollision(i, j):
	j.life -= ((abs(i.dx)+abs(i.dy))**2 / (abs(i.dx)+abs(i.dy) + abs(j.dx)+abs(j.dy)) ) / (30.0/i.rad)
	i.life -= ((abs(j.dx)+abs(j.dy))**2 / (abs(i.dx)+abs(i.dy) + abs(j.dx)+abs(j.dy)) ) / (30.0/j.rad)

	y = (j.rect.centery - i.rect.centery)
	x = (j.rect.centerx - i.rect.centerx)
	d2 = x * x + y * y
	kji = (x * i.dx + y * i.dy) / d2
	kii = (x * i.dy - y * i.dx) / d2
	kij = (x * j.dx + y * j.dy) / d2
	kjj = (x * j.dy - y * j.dx) / d2
	i.dy = kij * y + kii * x
	i.dx = kij * x - kii * y
	j.dy = kji * y + kjj * x
	j.dx = kji * x - kjj * y

def speed_from_vector(angle,speed):
	xspeed = math.cos(angle) * speed
	yspeed = math.sin(angle) * speed
	return xspeed, yspeed

def angle_from_points(p1,p2):
	x = p1[0] - p2[0]
	y = p1[1] - p2[1]
	return math.atan2(y,x) - math.pi

def distance(a,b):
	return math.sqrt(abs(a[0]-b[0])**2+abs(a[1]-b[1])**2)



class BFBall(pygame.sprite.Sprite):
	def __init__(self,bf,image,x,y,accel,maxd,life,el=0.55,friction=0):
		pygame.sprite.Sprite.__init__(self)
		self.bf = bf
		self.image, self.rect = load_image(os.path.join(picsdir,image), "alpha")
		self.rect.center = (x,y)
		self.dx = 0.0
		self.dy = 0.0
		self.accel = float(accel)
		self.maxd = float(maxd)
		self.el = el
		self.friction = float(friction)
		self.rad = float(self.rect.centerx - self.rect.left)
		self.ecolor = self.image.get_at((self.rad,self.rad))
		self.maxlife = self.life = float(life)
		self.score = 0

	def showHP(self,surface):
		p = int((self.life/self.maxlife)*self.rad*2)
		bar = pygame.Rect(self.rect.centerx-p/2,self.rect.top-10, p,5)
		pygame.draw.rect(surface,(0,255,0),bar)

	def check_for_collisions(self):
		for ball in self.bf.enemies:
			if distance(self.rect.center,ball.rect.center) != 0.0:
				if self.rect.colliderect(ball.rect) and self.collide(ball):
					calcCollision(self,ball)

	def collide(self,ball):
		dis = distance(self.rect.center,ball.rect.center)
		if dis < self.rad+ball.rad:
			dif = self.rad+ball.rad-dis
			angle = angle_from_points(self.rect.center,ball.rect.center)
			ball.rect.center = (ball.rect.centerx+math.cos(angle)*dif, ball.rect.centery+math.sin(angle)*dif)
			return True
		return False

	def boundaries(self):
		if self.rect.left < XMINBOUND:
			self.rect.left = XMINBOUND
			self.dx*=-self.el
			self.life -= 0.1
		elif self.rect.right > XMAXBOUND:
			self.rect.right = XMAXBOUND
			self.dx*=-self.el
			self.life -= 0.1
		if self.rect.top < YMINBOUND:
			self.rect.top = YMINBOUND
			self.dy*=-self.el
			self.life -= 0.1
		elif self.rect.bottom > YMAXBOUND:
			self.rect.bottom = YMAXBOUND
			self.dy*=-self.el
			self.life -= 0.1

	def attrite(self):
		if self.dx > 0.0:
			self.dx -= self.friction
		elif self.dx < 0.0:
			self.dx += self.friction
		if self.dy > 0.0:
			self.dy -= self.friction
		elif self.dy < 0.0:
			self.dy += self.friction

	def update(self):
		pass

	def draw(self, surface):
		surface.blit(self.image, self.rect.topleft)
		self.showHP(surface)

	def destroy(self):
		self.bf.player.score += self.score
		self.bf.player.life += self.maxlife/5.0
		if self.bf.player.life > self.bf.player.maxlife: self.bf.player.life = self.bf.player.maxlife
		self.bf.explosion(self.rect.centerx,self.rect.centery,self.ecolor,self.rad)
		self.kill()



class BFPlayer(BFBall):
	plimage = None
	def __init__(self,bf):
		BFBall.__init__(self,bf,"player.png",XMAXBOUND,YMAXBOUND,0.6,15,1000,0.55,0.1)
		BFPlayer.plimage = self.image.copy()
		BFPlayer.godimage = load_image(os.path.join(picsdir,'god.png'),'alpha')[0]
		BFPlayer.fastimage = load_image(os.path.join(picsdir,'fast.png'),'alpha')[0]
		BFPlayer.tankimage = load_image(os.path.join(picsdir,'tank.png'),'alpha')[0]
		BFPlayer.godfastimage = load_image(os.path.join(picsdir,'godfast.png'),'alpha')[0]
		BFPlayer.godtankimage = load_image(os.path.join(picsdir,'godtank.png'),'alpha')[0]
		BFPlayer.fasttankimage = load_image(os.path.join(picsdir,'fasttank.png'),'alpha')[0]
		BFPlayer.godfasttankimage = load_image(os.path.join(picsdir,'godfasttank.png'),'alpha')[0]
		self.god = 0
		self.fast = 1
		self.tank = 1
		self.memlife = self.life

	def showHP(self,surface):
		c = int(self.life/4.0)
		if c < 0:
			c=1
		elif c > 255:
			c=254
		zTextDraw(surface, "Health:", 30, (10,10), color=(255,c,c))
		l = abs(int(self.life/2.3))
		if self.life <= 0: l=1
		pygame.draw.rect(surface, (255,c,c), pygame.Rect(100, 10, l, 20))
		zTextDraw(surface, "Score: %012d" %self.score, 30, (580,10), color=(0,0,255))

	def update(self):
		if self.god and self.fast>1 and self.tank>1:
			self.image = BFPlayer.godfasttankimage.copy()
			self.life = self.memlife
			self.accel = 1.0
			self.maxd = 3.0
		elif self.fast>1 and self.tank>1:
			self.image = BFPlayer.fasttankimage.copy()
			self.accel = 1.0
			self.maxd = 3.0
		elif self.god and self.tank>1:
			self.image = BFPlayer.godtankimage.copy()
			self.life = self.memlife
			self.accel = 1.0
			self.maxd = 3.0
		elif self.god and self.fast>1:
			self.image = BFPlayer.godfastimage.copy()
			self.life = self.memlife
		elif self.god:
			self.image = BFPlayer.godimage.copy()
			self.life = self.memlife
		elif self.fast>1:
			self.image = BFPlayer.fastimage.copy()
		elif self.tank>1:
			self.image = BFPlayer.tankimage.copy()
			self.accel = 1.0
			self.maxd = 3.0
		else:
			self.image = BFPlayer.plimage.copy()

		for ball in self.bf.enemies:
			if self.rect.colliderect(ball.rect) and self.collide(ball):
				if self.tank>1: ball.life -= self.rad*self.tank
				calcCollision(self,ball)

		keys = pygame.key.get_pressed()
		if keys[K_LEFT] or keys[K_a]:
			self.dx -= self.accel*self.fast
		if keys[K_RIGHT] or keys[K_d]:
			self.dx += self.accel*self.fast
		if keys[K_UP] or keys[K_w]:
			self.dy -= self.accel*self.fast
		if keys[K_DOWN] or keys[K_s]:
			self.dy += self.accel*self.fast

		self.attrite()
		if self.dx > self.maxd*self.fast: self.dx = self.maxd*self.fast
		elif self.dx < -self.maxd*self.fast: self.dx = -self.maxd*self.fast
		if self.dy > self.maxd*self.fast: self.dy = self.maxd*self.fast
		elif self.dy < -self.maxd*self.fast: self.dy = -self.maxd*self.fast

		self.rect.move_ip(int(round(self.dx)), int(round(self.dy)))
		self.boundaries()

	def destroy(self):
		self.bf.explosion(self.rect.centerx,self.rect.centery,self.ecolor,self.rad*5)
		self.kill()



class BFEnemy(BFBall):
	def __init__(self,bf,image,x,y,accel,maxd,life,el=0.55,friction=0):
		BFBall.__init__(self,bf,image,x,y,accel,maxd,life,el,friction)
		self.target = self.bf.player

	def update(self):
		self.check_for_collisions()

		if self.rect.center[0] > self.target.rect.center[0]:
			self.dx -= self.accel
		if self.rect.center[0] < self.target.rect.center[0]:
			self.dx += self.accel
		if self.rect.center[1] > self.target.rect.center[1]:
			self.dy -= self.accel
		if self.rect.center[1] < self.target.rect.center[1]:
			self.dy += self.accel

		self.attrite()
		if self.dx > self.maxd: self.dx = self.maxd
		elif self.dx < -self.maxd: self.dx = -self.maxd
		if self.dy > self.maxd: self.dy = self.maxd
		elif self.dy < -self.maxd: self.dy = -self.maxd

		self.rect.move_ip(int(round(self.dx)),int(round(self.dy)))
		self.boundaries()

##########################   ENEMIES   ################################
class Tiny(BFEnemy):
	rate = 15
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"tiny.png",XMINBOUND,YMAXBOUND,0.25,10,10,0.45,0.15)
		self.score = 100

class Tinyfast(BFEnemy):
	rate = 20
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"tinyfast.png",XMINBOUND,YMAXBOUND,0.4,14,10,0.45,0.1)
		self.score = 200

class Small(BFEnemy):
	rate = 20
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"small.png",XMINBOUND,YMAXBOUND,0.35,12,40,0.5,0.2)
		self.score = 400

class Smallfast(BFEnemy):
	rate = 25
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"smallfast.png",XMINBOUND,YMAXBOUND,0.55,20,50,0.7,0.08)
		self.score = 600

class Medium(BFEnemy):
	rate = 35
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"medium.png",XMINBOUND,YMAXBOUND,0.2,50,200,0.35,0.07)
		self.score = 800

class Iper(BFEnemy):
	rate = 60
	score = 1200
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"iper.png",XMINBOUND,YMAXBOUND,0.9,100,100,0.9,0.0)

class Big(BFEnemy):
	rate = 50
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"big.png",XMINBOUND,YMAXBOUND,0.15,8,350,0.2,0.05)
		self.score = 1800

class WOOT(BFEnemy):
	rate = 80
	def __init__(self,bf):
		BFEnemy.__init__(self,bf,"woot.png",XMINBOUND,YMAXBOUND,1.0,2.8,800,1.0,0.0)
		self.score = 5000


class Planet(BFBall):
	rate = 300
	def __init__(self,bf):
		BFBall.__init__(self,bf,"planet.png",XMINBOUND,YMAXBOUND,130.0,30.0,5,1.0,0.0)
		self.score = 3000
		self.target = self.bf.player
		self.rad *= 2.0

	def update(self):
		self.check_for_collisions()

		speed = self.accel*self.rad*self.target.rad/distance(self.rect.center,self.target.rect.center)**2
		angle = angle_from_points((self.rect.center),(self.target.rect.center))
		self.dx += speed_from_vector(angle,speed)[0]
		self.dy += speed_from_vector(angle,speed)[1]

		if self.dx > self.maxd: self.dx = self.maxd
		elif self.dx < -self.maxd: self.dx = -self.maxd
		if self.dy > self.maxd: self.dy = self.maxd
		elif self.dy < -self.maxd: self.dy = -self.maxd
		self.rect.move_ip(int(round(self.dx)),int(round(self.dy)))
		self.boundaries()

class SuperPlanet(BFBall):
	rate = 500
	def __init__(self,bf):
		BFBall.__init__(self,bf,"superplanet.png",XMINBOUND,YMAXBOUND,80.0,35.0,8,1.0,0.0)
		self.score = 10000
		self.target = self.bf.player
		self.rad *= 5.0

	def update(self):
		self.check_for_collisions()

		speed = self.accel*self.rad*self.target.rad/distance(self.rect.center,self.target.rect.center)**2
		angle = angle_from_points((self.rect.center),(self.target.rect.center))
		self.dx += speed_from_vector(angle,speed)[0]
		self.dy += speed_from_vector(angle,speed)[1]

		if self.dx > self.maxd: self.dx = self.maxd
		elif self.dx < -self.maxd: self.dx = -self.maxd
		if self.dy > self.maxd: self.dy = self.maxd
		elif self.dy < -self.maxd: self.dy = -self.maxd
		self.rect.move_ip(int(round(self.dx)),int(round(self.dy)))
		self.boundaries()

#############################   POWER UPS   #####################################
class BFPowerup(pygame.sprite.Sprite):
	def __init__(self,bf,image,time):
		pygame.sprite.Sprite.__init__(self)
		self.bf = bf
		self.image, self.rect = load_image(os.path.join(picsdir,image),"alpha")
		self.time = time
		self.rect.center = (rand(XMINBOUND,XMAXBOUND),rand(YMINBOUND,YMAXBOUND))

	def activate(self):
		pass

	def countdown(self):
		self.time -= 1
		if self.time <= 0:
			self.kill()

	def update(self):
		if self.bf.time == 0.0:
			self.countdown()
		if self.rect.colliderect(self.bf.player.rect):
			self.bf.powerup_sound.play()
			self.activate()
			self.kill()

	def draw(self,surface):
		surface.blit(self.image, self.rect.topleft)



class Kill1(BFPowerup):
	rate = 25
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'kill1_pwup.png',10)

	def activate(self):
		life = 0
		for e in self.bf.enemies:
			if e.life > life and not isinstance(e,WOOT):
				life = e.life
		for e in self.bf.enemies:
			if e.life == life:
				e.destroy()
				break

class KillAll(BFPowerup):
	rate = 220
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'killall_pwup.png',15)

	def activate(self):
		for e in self.bf.enemies:
			e.destroy()

class Health(BFPowerup):
	rate = 100
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'health_pwup.png',10)

	def activate(self):
		for e in self.bf.enemies:
			self.bf.player.life += self.bf.player.maxlife/10
			if self.bf.player.life > self.bf.player.maxlife: self.bf.player.life = self.bf.player.maxlife

class SuperHealth(BFPowerup):
	rate = 250
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'superhealth_pwup.png',15)

	def activate(self):
		for e in self.bf.enemies:
			self.bf.player.life += self.bf.player.maxlife/3
			if self.bf.player.life > self.bf.player.maxlife: self.bf.player.life = self.bf.player.maxlife




class Godmode(BFPowerup):
	rate = 120
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'god_pwup.png',15)

	def activate(self):
		self.bf.player.god += 1
		self.image = pygame.Surface((1,1))
		self.image.set_alpha(0)
		self.bf.player.memlife = self.bf.player.life
		self.time = -15

	def deactivate(self):
		self.bf.player.god -= 1
		self.kill()

	def countup(self):
		self.time += 1
		if self.time >= 0:
			self.deactivate()

	def update(self):
		if self.bf.time == 0.0:
			if self.time < 0:
				self.countup()
			else:
				self.countdown()
		if self.rect.colliderect(self.bf.player.rect) and self.time > 0:
			self.bf.powerup_sound.play()
			self.activate()


class Speed(BFPowerup):
	rate = 75
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'speed_pwup.png',15)

	def activate(self):
		self.bf.player.fast*=2.0
		self.image = pygame.Surface((1,1))
		self.image.set_alpha(0)
		self.time = -20

	def deactivate(self):
		self.bf.player.fast/=2.0
		self.kill()

	def countup(self):
		self.time += 1
		if self.time >= 0:
			self.deactivate()

	def update(self):
		if self.bf.time == 0.0:
			if self.time < 0:
				self.countup()
			else:
				self.countdown()
		if self.rect.colliderect(self.bf.player.rect) and self.time > 0:
			self.bf.powerup_sound.play()
			self.activate()

class Tank(BFPowerup):
	rate = 180
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'tank_pwup.png',15)

	def activate(self):
		self.bf.player.tank*=4
		self.image = pygame.Surface((1,1))
		self.image.set_alpha(0)
		self.time = -10

	def deactivate(self):
		self.bf.player.tank/=4
		self.bf.player.accel = 0.6
		self.bf.player.maxd = 15.0
		self.kill()

	def countup(self):
		self.time += 1
		if self.time >= 0:
			self.deactivate()

	def update(self):
		if self.bf.time == 0.0:
			if self.time < 0:
				self.countup()
			else:
				self.countdown()
		if self.rect.colliderect(self.bf.player.rect) and self.time > 0:
			self.bf.powerup_sound.play()
			self.activate()

class Blackhole(BFPowerup):
	rate = 250
	def __init__(self,bf):
		BFPowerup.__init__(self,bf,'blackhole.png',15)

	def activate(self):
		self.bf.player.life /= 2.35

	def update(self):
		if self.bf.time == 0.0:
			self.countdown()
		if self.rect.colliderect(self.bf.player.rect):
			self.activate()
			self.kill()
		for e in self.bf.enemies:
			speed = 1200*e.rad/distance(self.rect.center,e.rect.center)**2
			angle = angle_from_points((e.rect.center),(self.rect.center))
			e.dx += speed_from_vector(angle,speed)[0]
			e.dy += speed_from_vector(angle,speed)[1]
			if self.rect.colliderect(e.rect):
				e.kill()

		speed = 1200*self.bf.player.rad/distance(self.rect.center,self.bf.player.rect.center)**2
		angle = angle_from_points((self.bf.player.rect.center),(self.rect.center))
		self.bf.player.dx += speed_from_vector(angle,speed)[0]
		self.bf.player.dy += speed_from_vector(angle,speed)[1]

